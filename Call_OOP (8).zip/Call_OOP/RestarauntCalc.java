/**
 * Calculates resteraunt
 *
 * Brian Call
 * 10.17.23
 */
import java.util.Scanner;
import javax.swing.JOptionPane;
import java.util.Date;
import java.text.DecimalFormat;
public class RestarauntCalc
{
    public static void Start(String[] args)
    {
        //initialize var
        String name;
        int burgerCount, fryCount, drinkCount;
        double tip;
        
        double burgerPCost = 4.50;
        double fryPCost = 2.50;
        double drinkPCost = 3.10;
        
        double burgerSCost, frySCost, drinkSCost;
        double burgerProfit, fryProfit, drinkProfit;
        
        String confirmation;
        
        double profit;
        
        Scanner input = new Scanner(System.in);
        
        //opening line/sign in 
        name = JOptionPane.showInputDialog(null, "Hi, can I get a name for your order?"); 
        confirmation = JOptionPane.showInputDialog(null, name + ". Did I spell that right?");
        
        //compare to yes and no
        boolean yee = confirmation.equals("Yes");
        boolean nee = confirmation.equals("No");
        
        //respond according to answer
        if(yee){
            JOptionPane.showMessageDialog(null, "Got it, " + name + ".");
        }
        else if(nee)
        {
            name = JOptionPane.showInputDialog(null, "Okay, what's the correct name?");
            JOptionPane.showMessageDialog(null, "Got it, " + name + ".");
        }
        else{
            JOptionPane.showMessageDialog(null, "I'm going to take that as a yes, " + name + ".");
        }
        JOptionPane.showMessageDialog(null, "It is currently " + new Date() + ".");
        
        //start text
        System.out.print("Hi, welcome to Chili's.");
        System.out.println("-----------------------");
        
        //ask borger
        System.out.println("Hey, so boss, how much should we sell the burgers for?");
        System.out.println("They cost " + burgerPCost  + " to make. Add decimal points. $");
        System.out.println("");
        burgerSCost = input.nextDouble();
        //test valid borger
        if(burgerSCost < burgerPCost)
        {
            System.out.println("That's too little. I'm going to sell them for $7.00 flat.");
            System.out.println("");
            burgerSCost = 7.00;
        }
        
        //ask fry
        System.out.println("Hey, so how about the fries?");
        System.out.println("They cost " + fryPCost  + " to make. $");
        System.out.println("");
        frySCost = input.nextDouble();
        //test valid fry
        if(frySCost < fryPCost)
        {
            System.out.println("That's too little. I'm going to sell them for $5.00 flat.");
            System.out.println("");
            frySCost = 5.00;
        }
        
        //test drank
        System.out.println("Lastly, how about the drinks?");
        System.out.println("They cost " + drinkPCost  + " to make. $");
        System.out.println("");
        drinkSCost = input.nextDouble();
        //check drank
        if(drinkSCost < drinkPCost)
        {
            System.out.println("That's too little. I'm going to sell them for $4.50 flat.");
            System.out.println("");
            frySCost = 4.50;
        }
        
        System.out.println("Okay, thanks. Hey, a customer's here!");
        System.out.println("------------------------------------");
        
        //start decimal format
        DecimalFormat df1 = new DecimalFormat("$#, ###, #00.00");//2 decimal points for mahney
        
        //start convo, ask borger
        System.out.println("");
        System.out.println("Hey, so like... how many burgers or whatever? It's " + df1.format(burgerSCost)+ ".");
        burgerCount = input.nextInt();
        System.out.println("Got it, " +  burgerCount + ".");
        
        //ask froi
        System.out.println("");
        System.out.println("Hey, so like fries? It's " + df1.format(frySCost) + ".");
        fryCount = input.nextInt();
        System.out.println("Cool, " + fryCount + ", got it.");
        
        //ask drank
        System.out.println("");
        System.out.println("You want any drinks? It's " + df1.format(drinkSCost) + ".");
        drinkCount = input.nextInt();
        System.out.println("Mhm, " + (drinkCount - 1) + " or, sorry, " + drinkCount + ".");
        
        //calculate costs
        double totalBurger = burgerSCost * burgerCount;
        double totalFry = frySCost * fryCount;
        double totalDrink = drinkSCost * drinkCount;
        double totalCost = totalBurger + totalFry + totalDrink;
        
        //print costs
        System.out.println("Okay, your burgers are gonna come out to " + df1.format(totalBurger)+ ".");
        System.out.println("Your fries are gonna come out to " +df1.format(totalFry)+ ".");
        System.out.println("And your drinks are gonna come out to " +df1.format(totalDrink)+ ".");
        System.out.println("Total cost: " +df1.format(totalCost)+ ".");
        System.out.println("Thank you!");
        
        System.out.println("---------------------------------");
        
        //calculate profit
        burgerProfit = (burgerSCost - burgerPCost) * 6 * burgerCount;
        fryProfit = (frySCost - fryPCost) * 6 * fryCount;
        drinkProfit = (drinkSCost - drinkPCost) * 6 * drinkCount;
        double totalProfit = burgerProfit + fryProfit + drinkProfit;
        
        //borger profit
        System.out.println("");
        System.out.println("Okay boss, so total count from today from our six different" +
        "\ncustomers that ordered the exact same order, from our " + burgerCount * 6 + " burgers," +
        "\n bringing in a total profit of " +  df1.format(burgerProfit) + ".");
        
        //froi profit
        System.out.println("");
        System.out.println("Total count for fries are " + fryCount * 6+ " fries," +
        "\n bringing in a total profit of " +  df1.format(fryProfit) + ".");
        
        //drank profit
        System.out.println("");
        System.out.println("And total count for drinks are " + drinkCount* 6 + " drinks," +
        "\n bringing in a total profit of " +  df1.format(drinkProfit) + ".");
        
        
        //total profit and progrm close
        System.out.println("");
        System.out.println("So finally, total profits come out to " + df1.format(totalProfit) + ".");
        System.out.println("With that, I'm going to finish up closing up shop. See you tomorrow!");
        System.out.print("\n                    "+
                         "\n    MMMMMMMMMMMMM   "+
                         "\n  MMMMMMMMMMMMMMMMM "+
                         "\n   |  _        _ |    "+
                         "\n   | |O|  MM  |O||    "+
                         "\n   |  T   MO   T |    "+
                         "\n   |  |   MM   | |    ");
    }
}
