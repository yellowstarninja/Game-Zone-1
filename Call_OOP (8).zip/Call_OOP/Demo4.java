
/**
 * Gets address using functions
 *
 * Brian Call
 * 11/1/23
 */
public class Demo4
{
    public static void main(String[] args)
    {
        System.out.println("We are going to call a method n call it\n with this program");
        SchoolAddress();//calling function
        ClosingBox();
    }
    
    public static void SchoolAddress()//creating function
    {
        System.out.println("Guam High School");
        System.out.println("401 Stitt Street");
        System.out.println("Hagatna, Guam 96910");
    }
    
    public static void ClosingBox()
    {
       System.out.println("******************");
       System.out.println("**              **");
       System.out.println("**              **");
       System.out.println("**      CYA.    **");
       System.out.println("**              **");
       System.out.println("**              **");
       System.out.println("******************");
    }
}
