/**
 * For mab libbering
 *
 * Brian Call
 * 11.3.23
 */

import javax.swing.JOptionPane;
import java.lang.Math;
import java.util.Scanner;
import java.util.Date;
public class MMLib
{
    public static void main(String[] args)
    {
        long integerVar, peopleCount, nonConvert; //define the variables
        double tempDouble;
        double actOneOdds;
        int oddsOfConversion;
        
        String word1, word2, word3, word4, word5, pCountStr;
        
        OpenLib();//print textBox1
        
        String name = JOptionPane.showInputDialog(null, "Hey, gimme ur name because I'm obligated to ask for it.", "Name");
        JOptionPane.showMessageDialog(null, "Okie, sup, " + name + ". It's " + new Date());
        
        JOptionPane.showMessageDialog(null, "Kay, in case ur allergic to fun, for madlibs you give me some words, and then I put them in a story in set positions. So gimme.", "Instructions", JOptionPane.INFORMATION_MESSAGE);
        
        //ask for the words
        word1 = JOptionPane.showInputDialog(null, "Give me a noun.", "Word One", JOptionPane.QUESTION_MESSAGE);
        word2 = JOptionPane.showInputDialog(null, "Give me a noun.", "Word Two", JOptionPane.QUESTION_MESSAGE);
        word3 = JOptionPane.showInputDialog(null, "Give me an adjective.", "Word Third", JOptionPane.QUESTION_MESSAGE);
        word4 = JOptionPane.showInputDialog(null, "Give me a verd. (No ing)", "Word Four", JOptionPane.QUESTION_MESSAGE);
        word5 = JOptionPane.showInputDialog(null, "Give me an adjective. (With ly)", "Word Five", JOptionPane.QUESTION_MESSAGE);
        pCountStr = JOptionPane.showInputDialog(null, "How many people will you show your poem to?", "People Count", JOptionPane.QUESTION_MESSAGE);
        
        String actOneOddsP = JOptionPane.showInputDialog(null, "What are the odds of these people getting to act two? (Decimal format like 0.3)", "Act One Odds", JOptionPane.QUESTION_MESSAGE);
        String oddsOfConversionP = JOptionPane.showInputDialog(null, "What are the odds of these people starting act two? (Integer format 1/x)", "Act Two Odds", JOptionPane.QUESTION_MESSAGE);
        
        actOneOdds = Double.parseDouble(actOneOddsP);
        oddsOfConversion = Integer.parseInt(oddsOfConversionP);
        
        peopleCount = Integer.parseInt(pCountStr);
        
        System.out.println("");//pointless text art 5
        System.out.println("    ____________    ");
        System.out.println("   |____________|    ");
        System.out.println("   |___ King ___|    ");
        System.out.println("   |_____In_____|    ");
        System.out.println("   |___Yellow___|    ");
        System.out.println("   |____________|    ");
        System.out.println("   |___Robert___|    ");
        System.out.println("   |__Chambers__|    ");
        System.out.println("   |____________|    ");

        //print mad lib poem
        System.out.println("");
        System.out.println("Here's your poem: ");
        System.out.println("  Along the shore the " + word1 + " waves break.");
        System.out.println("  The twin suns sink beneath the " + word2 + ".");
        System.out.println("  The shadows lengthen");
        System.out.println("                                 In Carcosa.");
        System.out.println("  ");
        System.out.println("  Strange is the night where " + word3 + " stars rise");
        System.out.println("  And strange moons circle through the skies,");
        System.out.println("  But stranger still is");
        System.out.println("                                 Lost Carcosa");
        System.out.println("  ");
        System.out.println("  Songs that the Hyades shall sing,");
        System.out.println("  Where " + word4 + " the tatters of the king,");
        System.out.println("  But stranger still is");
        System.out.println("                                 Dim Carcosa");
        System.out.println("  ");
        System.out.println("  Song of my soul, my voice is dead, ");
        System.out.println("  Die thou, unsung, as tears unshed");
        System.out.println("  Shall dry and die in");
        System.out.println("                                 " + word5 + " Carcosa");
        System.out.println("");
        
        System.out.println("");
        System.out.println(" O");
        System.out.println("oVo[-]");
        System.out.println(" |  ");
        System.out.println("_^_ ");
        
        //calculate conversion and act 2
        tempDouble = peopleCount * actOneOdds;
        integerVar = Math.round(tempDouble);
        integerVar = integerVar / oddsOfConversion;
        nonConvert = peopleCount - integerVar;

        //print conversion and act 2
        System.out.println(integerVar + " people got to act two.");
        System.out.println("Your poem converted " + integerVar + " people.");
        System.out.println(nonConvert + " people were not converted");
        System.out.println("");
        
        CloseLib();//closeBox
    }
    
    public static void OpenLib()
    {
       System.out.println("********************************************");//openingBox
       System.out.println("**       Welcome to Mab Libbing-er        **");
       System.out.println("**            With Dingus Boy             **");
       System.out.println("**                                        **");
       System.out.println("** Now with psychologically scarring fun! **");
       System.out.println("**        Thanks to Lost Carcosa          **");
       System.out.println("********************************************");        
    }
    
    
    public static void CloseLib()
    {
       System.out.println("********************************************");//closingBox
       System.out.println("**       Thanks for Mab Libber-ing        **");
       System.out.println("**            With Dingus Boy             **");
       System.out.println("**                                        **");
       System.out.println("**Dingus boy is not liable for any trauma!**");
       System.out.println("**      That falls on Lost Carcosa        **");
       System.out.println("********************************************");        
    }
}
