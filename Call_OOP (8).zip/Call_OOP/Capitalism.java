
/**
 * Takes money from u and gives it to gobermint but it tell u waht gib gubersmint
 *
 * Brian Call
 * 10.25.23
 */
import java.util.Scanner;
import javax.swing.JOptionPane;
import java.util.Date;
import java.text.DecimalFormat;
public class Capitalism
{
     public static void Function(String[] args){
        double hourlyrate, hoursWorked, withholdingTax, grossPay, netPay;
        final double TAXRATE = 0.15;
         
        String nerd, hourRateS, hourWorkS;
        nerd = JOptionPane.showInputDialog(null, "Hey, nerd, sign in cuz I'm obligated to tell you to: ");
        JOptionPane.showMessageDialog(null, "Okay, sup " + nerd + ".");
        
        DecimalFormat df = new DecimalFormat("#,###,#00.00");
        
        JOptionPane.showMessageDialog(null, "So this tax calc", "Intro", JOptionPane.INFORMATION_MESSAGE);
        
        hourRateS = JOptionPane.showInputDialog(null, "How much per hour poor person (decimal places):",
            "Hour raete", JOptionPane.QUESTION_MESSAGE);
        hourlyrate = Double.parseDouble(hourRateS);
        
        hourWorkS = JOptionPane.showInputDialog(null, "How *many* hour broke boy (decimal places):",
            "Hour coent", JOptionPane.QUESTION_MESSAGE);
        hoursWorked = Double.parseDouble(hourWorkS);
        
        
        grossPay = hourlyrate * hoursWorked;
        withholdingTax = grossPay * TAXRATE;
        netPay = grossPay - withholdingTax;
        
        JOptionPane.showMessageDialog(null, "You gross earg: " + df.format(grossPay), "Gross pai", JOptionPane.INFORMATION_MESSAGE);
        JOptionPane.showMessageDialog(null, "Tax wuz: " + df.format(withholdingTax), "Tax mount", JOptionPane.INFORMATION_MESSAGE);
        JOptionPane.showMessageDialog(null, "Totul pae iz: " + df.format(netPay), "Totul Pae", JOptionPane.INFORMATION_MESSAGE);
        
        JOptionPane.showMessageDialog(null, "Kay, go away.", "Later", JOptionPane.INFORMATION_MESSAGE);
    }
     
}
