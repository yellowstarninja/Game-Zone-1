/**
 * Program description: 
 *
 * Programmer: 
 * Date: 
 */
import javax.swing.JOptionPane; //spelled wrong twice
import java.util.Scanner; //util not text
public class DebugOOPData1
{
    public static void Main(String[] args) //removed semicolon
    {
        //Section 1.
        System.out.println("Java programming is fun. \nGetting a program to work can be a challenge,");//challenge
        System.out.println("but when everything works correctly, it's very satisfying.");//it's
        System.out.println(); //needs ln
         
        //Section 2.
        JOptionPane.showMessageDialog(null, "Welcome to Java Department!"); //needs null
        String name = JOptionPane.showInputDialog(null, "Please sign-in.", "Visitor Sign-In", 
            JOptionPane.QUESTION_MESSAGE); //fixed it to Input
        JOptionPane.showMessageDialog(null, "Hello " + name + "...Aim High, Guam High!");
        
        //Section 3.
        System.out.println("Demonstration of Datatypes and Simple Math:");
        int numInt = 175;
        double numDouble = 15.7; //its not an int
        char letterChar = 'M'; //switched to single quotation marks
        int a, b, c;
        a = 22;
        b = 15;
        c = a * b;
        System.out.println("The integer is " + numInt + ".");//fixed to ln
        System.out.println("The double is " + numDouble); //changed message
        System.out.println("The character is " + letterChar);
        System.out.println("The product of " + a + " and " + b + " is " + c); //lowercased the C
        System.out.println(); // No semicolon
    }
} //missing bracket