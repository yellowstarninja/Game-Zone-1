public class TestScript
{
    private int x;


    public TestScript()
    {
        // initialise instance variables
        x = 0;
    }

    public int sampleMethod(int y)
    {
        // put your code here
        return x + y;
    }
}
