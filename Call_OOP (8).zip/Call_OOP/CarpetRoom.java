/**
 *Does carpet dimension-y things
 *
 * Brian Call
 * 10.13.23
 */
import java.util.Scanner;
import javax.swing.JOptionPane;
import java.util.Date;
import java.text.DecimalFormat;
public class CarpetRoom
{
    public static void Starter(String[] args){
        
        //program open
        
        System.out.println("\'Welcome to my Room Carpet Calculator \'");
        System.out.println("***************************************");
        System.out.println();
        
        String customer;
        customer = JOptionPane.showInputDialog(null, "Sign in coward"); 
        JOptionPane.showMessageDialog(null, "Sup nerd, " + customer + "\n" + new Date());
        
        //var definition
        
        double length, width; //enter Room dimensions
        double area; //find the ft^2 area of a room
        double price, cost; //to know the price and cost
        String lengthS, widthS; //for GUI user input
        
        Scanner input = new Scanner(System.in);
        /*System.out.print("Enter the length of the room in ft");
        length = input.nextDouble();
        System.out.print("Enter width in ft ->");
        width = input.nextDouble();*/
        lengthS = JOptionPane.showInputDialog(null, "Enter room length in ft:",
            "Length of Room", JOptionPane.QUESTION_MESSAGE);
        length = Double.parseDouble(lengthS);
        
        widthS = JOptionPane.showInputDialog(null, "Enter room width in ft:",
            "Width of Room", JOptionPane.QUESTION_MESSAGE);
        width = Double.parseDouble(lengthS);
        System.out.println();
        
        area = length * width; //calcuate area of room
        
        //console output
        DecimalFormat df1 = new DecimalFormat("#,###,#00.000");
        /*System.out.println("Your room dimension is " + length + " ft. by " + width + " ft.");
        System.out.println("Therefore the sqft. of the room is " + df1.format(area) + ".");*/
        JOptionPane.showMessageDialog(null, "The area of your room is " + df1.format(area) + "sqft.", 
        "Room area", JOptionPane.INFORMATION_MESSAGE);
        
        //carpet price
        System.out.println("---------------------------------------------------------");
        System.out.println("Cost to carpet a room.");
        System.out.println("Enter the cost of your carpet per sqft. --> $");
        price = input.nextDouble();
        System.out.println();
        cost = area * price; //calculates total price 

        //decimal point method
        DecimalFormat df2 = new DecimalFormat("$#, ###, #00.00");//2 decimal points for mahney
        
        //room dimensions and the cost per sqft
        System.out.println("Therefore the cost to carpet your room is " + df2.format(cost) + " .");
        
        System.out.println();
        System.out.println("Carpet specs: \nBig rug. Spaghetti flavored." + "\nLowes");
        System.out.println("***************************************");
        
        //program close  
        System.out.println("Thanks nerd.");
        
    }
}
