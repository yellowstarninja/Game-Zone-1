
/**
 *Meets the assignment requirements, hopefully
 *
 *Brian Call
 *9.28.23
 */

import java.util.Date;
import javax.swing.JOptionPane;
public class ThisIsHowWeDoIt
{
    public static void main(String[] args)
    {
        int sleepHours = 3;
        double brainCells = 100;
        int awakeHours = 21;
        int neededSleep = 7;
        String name = "Brian";
        
        double sum, diff, prod, quot;
        //DIY code
        //Define variables
        sum = sleepHours + neededSleep;
        diff = awakeHours - neededSleep;
        quot = brainCells / sleepHours;
        prod = quot * sum;
        
        //Math section
        System.out.println("\tIf you add the amount of sleep I still need to get (" + neededSleep + ")," + 
        "\nplus the amount of sleep I actually got (" + sleepHours + "), you get " + sum + "hours of sleep.");
        
        System.out.println();        
        
        System.out.println("If you subtract the amount of sleep I still need to get (" + neededSleep + ")," + 
        "\nplus the amount of hours left in the day (" + sleepHours + "), you get " + diff + "hours of daylight.");
        
        System.out.println();
        
        System.out.println("If you divide the amount of 'sleep' I got (" + sleepHours + ")," + 
        "\nby my brain cell count(" + brainCells + "), you get " + quot + ", my sleep:brain cell ratio.");

        System.out.println();
        
        System.out.println("If you multiply my sleep:braincell ratio (" + quot + ")," + 
        "\nby the amount of sleep I should get (" + sum + "), you get " + prod + " brain cells on\n a full nights rest.");

        System.out.println();
        //Date printer
        JOptionPane.showMessageDialog(null, "The date is " + new Date() + " right now.");
        //Line art
        System.out.println(" V");
        System.out.println("-O-");
        System.out.println("-O-");
        System.out.println("-O-");
        System.out.println("-O-");
        System.out.println("Catterpitter");
        
        
    }
}
