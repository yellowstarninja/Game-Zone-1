
/**
 * Write a description of class Hello here.
 *
 * Programmer: Brian
 * Date: 9.14.23
 */
public class Hello
{
    public static void main(String[] args)
    {
        System.out.println("Skibbi dee bopp mm bop");
    }
}
