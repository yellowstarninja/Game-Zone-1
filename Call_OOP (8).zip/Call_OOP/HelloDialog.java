
/**
 * First dialogue box, GUI output
 *
 * Brian Call
 * 0.1
 */
import javax.swing.JOptionPane;
public class HelloDialog
{
    public static void main(String[] args)
    {
         JOptionPane.showMessageDialog(null, "Sup Dingus");
         JOptionPane.showMessageDialog(null, "We are Guhreit (hey)");
         System.out.println("     *     \n    XXX    O\n   XXXXX   V\n  XXXXXXX  |\n     X     ^");
    }
}
