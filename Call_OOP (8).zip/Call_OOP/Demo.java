
/**
 * Write a description of class Demo here.
 *
 * Brian Call
 * 9.26.23
 */
import java.util.Date;
import javax.swing.JOptionPane;
public class Demo
{
    public static void main(String[] args)
    {
        //it says things *thumbs up*
        System.out.println("Stephen King war crimes" + 
            "\navacado!");
        System.out.println("");
        System.out.println("Make sure you ALWASYS \'INCERUDE ASGIN\'" +
            "\naisognaisnoin\n");
        System.out.println("Students gonna have long time " +
            "\n\tfree soon wowie! \nYou??");
            
        //date method.
        System.out.println("\nHello Student, \nyou logged in, that's pretty poggers, " + new Date());
        //data types
        int number2 = 7;
        double number1 = 12.0;
        double pay = 9.50;
        double hours = 20;
        double sum, subtract, mult, divide;
        String name = "Tony";
        
        //calling le var
        sum = number1 + number2; // initialize the sum 
        subtract = number1 - number2; // initialize the difference
        mult = number1 * number2; // intitalize the product
        divide = number1 / number2; // initialize the quotient
        System.out.println(number1 + " plus " + number2 + " = " + sum); //prints equation for sum
        System.out.println(number1 + " minus " + number2 + " = " + subtract); //prints equation for difference
        System.out.println(number1 + " multipied by " + number2 + " = " + mult); // prints equation for product
        System.out.println(number1 + " divided by " + number2 + " = " + divide); // prints equation for quotient
        
        double mult2 = pay * hours;
        JOptionPane.showMessageDialog(null, "Your pay is be $" + pay + " and \nyou worked " + hours + 
        ". Chop chop." + " Therefore your pay will be " + mult2 + ".");
        
        JOptionPane.showMessageDialog(null, "Hey, it's me, " + name + "!");
        

    }
}
