
/**
 * Demonstrate user input
 *
 * Brian Call
 * 10.5.23
 */

import java.util.Date;//for date
import javax.swing.JOptionPane;//GUI output
import java.util.Scanner;//console user input
import java.text.DecimalFormat; //round off decimal values
public class Demo2
{
    public static void Demo2(String[] args)
    {
        //var definition
        String name;
        int grade;
        String village, school;
        double area;
        double length1;
        double length2;
        
        //user input n response
        name = JOptionPane.showInputDialog(null, "Sign in.",
        "Student Sign-In,", JOptionPane.QUESTION_MESSAGE);
       
        Scanner input = new Scanner(System.in); //for consul input
        System.out.print("What village is u from?");
        village = input.nextLine();
        System.out.print("What grade level is u?");
        grade = input.nextInt();
        input.nextLine();
        System.out.print("What high school is u from is?");
        school = input.nextLine();
        
        System.out.print("Enter the legnth of your table >> ");
        length1 = input.nextDouble();
        System.out.print("Enter the width of your table >> ");
        length2 = input.nextDouble();
        
        area = length1 * length2; 
        
        JOptionPane.showMessageDialog(null, "Hello " + name + "!");
        JOptionPane.showMessageDialog(null, "You signed in on: " + new Date());

        System.out.print("You is from " + village + ". ");
        System.out.print("You is grade " + grade + ". ");
        System.out.print("You is from schoo " + school + ".");
        System.out.print("Table area is... " + area + ".");
        
        
        
    }
}
