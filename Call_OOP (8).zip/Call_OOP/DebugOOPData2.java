/**
 * Program description: NO OPENING DEFITIONS
 *
 * Programmer: 
 * Date: 
 */
import javax.swing.JOptionPane;//swing not util
import java.util.Scanner; //no x
public class DebugOOPData2
{
    public static void main(String[] args)//string in caps, added static
    {
        //Section 4.
        String relative;
        int age;//int not integer
        double squareFeet, length, width,guess; //comma not semicolon
        
        
        Scanner input = new Scanner(System.in);//in not out
        
        System.out.println("Guesstimate a relative's house dimensions in square feet: ");//scooted answer and actual read it & fixed spelling & space
        guess = input.nextDouble();
        
        System.out.println("What is your cousin's name? "); 
        relative = input.nextLine();//nextLine
        System.out.println("How old is your relative? ");
        age = input.nextInt();//nextInt not nextDouble

        System.out.println("Guesstimate the length of your neighbor's house in feet >> ");
        length = input.nextDouble();//parenthesis
        System.out.println("Guesstimate the width of your relative's house in feet >> ");//spaced feet
        width = input.nextDouble();//parenthesis
        squareFeet = length * width;//capitalize Feet & multiply

        System.out.println("Your relative's name is " + relative + ", about " + age + " years old.");//fixed variable positions
        System.out.println("There house square ft is about " + squareFeet + " sqft, and you guessed " + guess + ".");//added the guess
    }
}//no bracket